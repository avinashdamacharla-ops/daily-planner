# Daylight — Daily Planner

A clean, responsive daily planner built with vanilla HTML, CSS, and JavaScript.

## Features
- Add, edit, complete, and delete daily tasks
- Task time and category labels
- All / To do / Done filters
- Daily completion stats and progress bar
- 25-minute focus timer
- Quick notes with automatic saving
- Browser localStorage persistence; no account or backend required

## Run locally
Open `index.html` in any modern browser.

## Publish with GitHub Pages
1. Create a GitHub repository named `daily-planner`.
2. Upload `index.html` and `README.md` to the repository root.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
5. Your app will be published at `https://YOUR-USERNAME.github.io/daily-planner/`.

Tasks and notes are stored in the current browser on the current device.
